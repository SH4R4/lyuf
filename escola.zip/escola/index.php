<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAMOSO FORMS</title>
</head>
<body>
    <form action="cadastrar.php" autocomplete ="off" method="POST" >
        <h1 align="Center">CADASTRO ALUNO</h1>

        <label for="id_produto">RA ....:</label>
        <input type="text" id="id_ra" name="ra" required>
        <br><br>

        <label for="id_nome">Aluno :</label>
        <input type="text" id="id_nome" name="nome" required>
        <br><br>

        <label for="id_bairroe">Bairro :</label>
        <input type="text" id="id_unidade" name="bairro">
        <br><br>

        <label for="id_endereco">Endereço :</label>
        <input type="text" id="id_valor1" name="endereco" required> 
        <br><br>

        <label for="id_cep">CEP :</label>
        <input type="text" id="id_cep" name="cep"> 
        <br><br>

        <label for="id_celular">Celular:</label>
        <input type="text" id="id_ipi" name="celular"> 
        <br><br>

        <label for="id_email">Email:</label>
        <input type="text" id="id_email" name="email"> 
        <br><br>

        <label for="id_data_nasc">Data Nasc. :</label>
        <input type="date" id="id_dt_nasc" name="dt_nasc" value="2018-05-29" 
        min="1950-05-29" max="2022-12-31"> 
        <br><br>

        <input type="submit" name="enviar" value="ENVIAR">  
    </form>

</body>
</html>