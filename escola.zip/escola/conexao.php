<?php
try{
    $pdo = new PDO('mysql:dbname=bd_escola;host=localhost','root','');
	//echo "<BR>conexao-5 $ pdo";
    
} catch (PDOException $e) {
    print "Erro: " . $e->getMessage() . "<br>";
    die();
}

?>