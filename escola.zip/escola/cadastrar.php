<?php
    echo "cadastro-2 FALTA GRAVAR DATA DE NASCIMENTO- DATA CADASTRO E TRUE";
    include_once("conexao.php");
    //echo "<br>cadastro4 - voltou include_one";
	//echo $pdo;
	//echo "<br>Cadastro 6 Acima pdo ";
    $ra      = $_POST['ra'];
    $nome    = $_POST['nome'];
    $bairro  = $_POST['bairro'];
    $endereco  = $_POST['endereco'];
    $cep       = $_POST['cep'];
    $email     = $_POST["email"];
    $celular   = $_POST['celular'];
    $dt_nasc    = $_POST['dt_nasc'];
   // $fornecedor = $_POST['fornecedor'];


	echo $ra."<BR>";
	echo $nome."<br>";
    echo $bairro."<BR>";
	echo $endereco."<br>";
    echo $cep."<br>";
    echo $email."<BR>";
	echo $celular."<br>";

    $verifica_produto = $pdo->prepare("SELECT ra FROM tb_aluno WHERE ra = :p");
    $verifica_produto->bindValue(":p", $ra);
    $verifica_produto->execute();
    $count = $verifica_produto->rowCount();
    //echo "<br>cadastro-20  variavel $count";
    if($count == 0){
        //$pdo->query("INSERT INTO produtos(produto, descricao, unidade_produtos, valor1, valor2, IPI, margem, fornecedor) VALUES('$produto','$descricao','$unidade','$valor1','$valor2','$IPI','$margem','$fornecedor')");
        $pdo->query("INSERT INTO tb_aluno(ra, nome, bairro, endereco, cep, email, celular) VALUES('$ra','$nome','$bairro','$endereco','$cep','$email','$celular',  )");
        echo"<br>Cadastro realizado com sucesso";
       #jjjjjjjjjjjjjjjjjjjjj echo ("<br>INSERT INTO produtos(produto, descricao, unidade_produtos, valor1, valor2, IPI, margem, fornecedor) VALUES('$produto','$descricao','$unidade','$valor1','$valor2','$ipi','$margem','$fornecedor')");
         
    }
    else{
        echo"Produto ja cadastrado";    
        //echo ("<BR>INSERT INTO produtos(produto, descricao, unidade_produtos, valor1, valor2, IPI, margem, fornecedor) VALUES('$produto','$descricao','$unidade','$valor1','$valor2','$ipi','$margem','$fornecedor')");
    } 
 
    
?>